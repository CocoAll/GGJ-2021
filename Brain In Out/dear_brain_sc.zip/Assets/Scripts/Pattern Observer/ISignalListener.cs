﻿namespace Unity.Utils.PatternObserver
{
    public interface ISignalListener
    {
        void OnSignalRaised();
    }
}
