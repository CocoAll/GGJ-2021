﻿public enum TypeEnum
{
    AMOUR,
    TRAVAIL,
    SOCIAL,
    NEUTRE
}